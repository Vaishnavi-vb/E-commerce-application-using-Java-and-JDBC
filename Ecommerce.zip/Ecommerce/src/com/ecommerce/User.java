package com.ecommerce;

import java.time.LocalDateTime;
import java.util.Scanner;

public class User {
	
	int user_id;
	String firstName;
	String lastName;
	String emailId;
	long mobNo;
	String password;
	String role;
	LocalDateTime createdAt;
	LocalDateTime updatedAt;
	
	
	public User() {
		// TODO Auto-generated constructor stub
	}


	public User(String firstName, String lastName, String emailId, long mobNo, String password,
			String role) {
		super();
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.mobNo = mobNo;
		this.password = password;
		this.role = role;
		
	}


	public int getUser_id() {
		return user_id;
	}


	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public long getMobNo() {
		return mobNo;
	}


	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public LocalDateTime getCreatedAt() {
		return createdAt;
	}


	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}


	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}


	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	
	
}
