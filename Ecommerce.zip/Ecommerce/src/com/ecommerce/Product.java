package com.ecommerce;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Product {
    int productid;
    String productName;
    double price;
    int stockQuantity;
    String description;
    LocalDateTime createdAt;
	LocalDateTime updatedAt;
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public Product( String productName, double price, int stockQuantity, String description) {
		super();
		
		this.productName = productName;
		this.price = price;
		this.stockQuantity = stockQuantity;
		this.description = description;
		this.createdAt = LocalDateTime.now();
		this.updatedAt = LocalDateTime.now();
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	
    
}
