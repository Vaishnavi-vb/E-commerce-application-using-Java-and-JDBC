package com.ecommerce;

public class Address {
	
	    private int addressId;
	    private String streetAddress;
	    private String city;
	    private String state;
	    private String postalCode;
	    private String country;
	    private String phoneNumber;
	    private String addressType; // "Shipping" or "Billing"
	    public Address() {
			// TODO Auto-generated constructor stub
		}
	    
	    public Address(String streetAddress, String city, String state, String postalCode, String country,
				String phoneNumber, String addressType) {
			super();
			this.streetAddress = streetAddress;
			this.city = city;
			this.state = state;
			this.postalCode = postalCode;
			this.country = country;
			this.phoneNumber = phoneNumber;
			this.addressType = addressType;
		}

		// Getters and Setters
	    public int getUserId() {
	        return addressId;
	    }
	    
	    public void setUserId(int userId) {
	        this.addressId = userId;
	    }
	    
	    public String getStreetAddress() {
	        return streetAddress;
	    }
	    
	    public void setStreetAddress(String streetAddress) {
	        this.streetAddress = streetAddress;
	    }

	    public String getCity() {
	        return city;
	    }

	    public void setCity(String city) {
	        this.city = city;
	    }

	    public String getState() {
	        return state;
	    }

	    public void setState(String state) {
	        this.state = state;
	    }

	    public String getPostalCode() {
	        return postalCode;
	    }

	    public void setPostalCode(String postalCode) {
	        this.postalCode = postalCode;
	    }

	    public String getCountry() {
	        return country;
	    }

	    public void setCountry(String country) {
	        this.country = country;
	    }

	    public String getPhoneNumber() {
	        return phoneNumber;
	    }

	    public void setPhoneNumber(String phoneNumber) {
	        this.phoneNumber = phoneNumber;
	    }

	    public String getAddressType() {
	        return addressType;
	    }

	    public void setAddressType(String addressType) {
	        this.addressType = addressType;
	    }
	

}
