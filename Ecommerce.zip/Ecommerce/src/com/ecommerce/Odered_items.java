package com.ecommerce;

import java.time.LocalDateTime;

public class Odered_items {
   int oderedId;
   double price;
   String status;
   LocalDateTime date;
   public Odered_items() {
	// TODO Auto-generated constructor stub
}
public Odered_items(int oderedId, double price, String status, LocalDateTime date) {
	super();
	this.oderedId = oderedId;
	this.price = price;
	this.status = status;
	this.date = date;
}
public int getOderedId() {
	return oderedId;
}
public void setOderedId(int oderedId) {
	this.oderedId = oderedId;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public LocalDateTime getDate() {
	return date;
}
public void setDate(LocalDateTime date) {
	this.date = date;
}
   
}
