package com.ecommerce;

public class Refund {
    private int refundId;
  //  private Order order;
    private double refundAmount;
    private boolean isProcessed;

    // Constructor, getters, setters
    public Refund(int refundId, double refundAmount) {
        this.refundId = refundId;
        //this.order = order;
        this.refundAmount = refundAmount;
        this.isProcessed = false;
    }

    public int getRefundId() {
        return refundId;
    }

//    public Order getOrder() {
//        return order;
//    }

    public double getRefundAmount() {
        return refundAmount;
    }

    public boolean isProcessed() {
        return isProcessed;
    }

    public void processRefund() {
        // Implement the logic for processing refund, like calling the payment gateway API
        this.isProcessed = true;
    }
}
