package com.ecommerce;

import java.sql.SQLException;
import java.util.Scanner;

public class Menu {
	public static void categoryMenu() {
		Authentication a = new Authentication();
		Scanner sc = new Scanner(System.in);
		CategoriesData c = new CategoriesData();
		int choice;
		do {
			System.out.println(
					"Enter choice\n1:ELectronics\n2:Home Applience\n3:Baby & Kids\n4:Men\n5:Women\n6:Sport\n7:Books\n0:Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1: {
				c.showAllElectronics();
			}
				break;
			case 2: {
				c.showAllHomeApllience();
			}
				break;
			case 3: {
				c.showBook();
			}
				break;
			case 4: {
				c.showMen();
			}
				break;
			case 5: {
				c.showSport();
			}
				break;
			case 6: {
				c.showWomens();
			}
				break;
			default: {
				System.out.println("Enter valid choice");
			}
				break;
			case 0: {
				System.out.println("Go back");
				return;
			}
			}
		}

		while (choice != 0);

	}

	public  void availableServicesForUser() throws SQLException {
		Scanner sc = new Scanner(System.in);
		int choice;
		do {
			System.out.println("Enter choice\n1:show products\n2:show category wise"
					+ "\n3:add to cart\n4:pruchase product \n5:add adreess\n6:update address\n7:cancel order \n0:Exit");
			choice = sc.nextInt();
			CategoriesData c = new CategoriesData();
			switch (choice) {

			case 1: {
				ProductService ps = new ProductService();
				ps.showAllProduct();
			}
				break;
			case 2: {
				categoryMenu();
			}
				break;
			case 3: {
				PurchaseData pd = new PurchaseData();
				System.out.println("Enter userId");
				int userId = sc.nextInt();
				System.out.println("Enter productId");
				int productId = sc.nextInt();
				System.out.println("Enter quantity");
				int quantity = sc.nextInt();
				pd.addToCart(userId, productId, quantity);
			}
				break;
			case 4: {
				PurchaseData pd = new PurchaseData();
				System.out.println("Enter userId");
				int userId = sc.nextInt();
				System.out.print("Enter payment method");
				String paymentMethod = sc.next();
				pd.completePurchase(userId, paymentMethod);
			}
				break;

			case 5: {
				AddressService as = new AddressService();
				System.out.print("Enter user ID: ");
				int userId = sc.nextInt();
				as.addAddress(userId);
			}
				break;

			case 6: {
				AddressService as = new AddressService();
				System.out.print("Enter user ID: ");
				int userId = sc.nextInt();
				as.updateAddress(userId);
			}
				break;
			case 7: {
				PurchaseData pd = new PurchaseData();
				System.out.println("Enter orderId");
				int orderId = sc.nextInt();

				pd.cancelOrder(orderId);
			}
				break;

			default: {
				System.out.println("Enter valid choice");
			}
				break;
			case 0: {
				System.out.println("Go back");
				return;
			}
			}
		}

		while (choice != 0);
	}

	public  void availableServices() throws SQLException {
		Scanner sc = new Scanner(System.in);
		int choice;
		do {
			System.out.println(
					"Enter choice\n1:Add Product\n2:add category\n3:add sub category\n4:\show products\n5:show category wise"
							+ "\n6:add to cart\n7:pruchase product \n8:add adreess\n9:update address\n10:cancel order \n11:Refund\n0:Exit");
			choice = sc.nextInt();
			CategoriesData c = new CategoriesData();
			switch (choice) {
			case 1: {
				ProductService ps = new ProductService();
				System.out.println("Enter your user id");
				int user_id = sc.nextInt();
				ps.addProduct(user_id);
			}
				break;
			case 2: {
				System.out.println("Enter category");
				sc.nextLine();
				String cat = sc.nextLine();
				c.addCategory(cat);
			}
				break;
			case 3: {
				System.out.println("Enter sub category");
				sc.nextLine();
				String sub = sc.nextLine();

				c.addSubCategories(sub);

			}
				break;
			case 4: {
				ProductService ps = new ProductService();
				ps.showAllProduct();
			}
				break;
			case 5: {
				categoryMenu();
			}
				break;
			case 6: {
				PurchaseData pd = new PurchaseData();
				System.out.println("Enter userId");
				int userId = sc.nextInt();
				System.out.println("Enter productId");
				int productId = sc.nextInt();
				System.out.println("Enter quantity");
				int quantity = sc.nextInt();
				pd.addToCart(userId, productId, quantity);
			}
				break;
			case 7: {
				PurchaseData pd = new PurchaseData();
				System.out.println("Enter userId");
				int userId = sc.nextInt();
				System.out.print("Enter payment method");
				String paymentMethod = sc.next();
				pd.completePurchase(userId, paymentMethod);
			}
				break;

			case 8: {
				AddressService as = new AddressService();
				System.out.print("Enter user ID: ");
				int userId = sc.nextInt();
				as.addAddress(userId);
			}
				break;

			case 9: {
				AddressService as = new AddressService();
				System.out.print("Enter user ID: ");
				int userId = sc.nextInt();
				as.updateAddress(userId);
			}
				break;
			case 10: {
				PurchaseData pd = new PurchaseData();
				System.out.println("Enter orderId");
				int orderId = sc.nextInt();

				pd.cancelOrder(orderId);
			}
				break;
			case 11:{
				RefundService rs=new RefundService();
				System.out.println("Enter orderId");
				int orderId = sc.nextInt();
				rs.processRefund(orderId);
			}

			default: {
				System.out.println("Enter valid choice");
			}
				break;
			case 0: {
				System.out.println("Go back");
				return;
			}
			}
		}

		while (choice != 0);
	}
}
