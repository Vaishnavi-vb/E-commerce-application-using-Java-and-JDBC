package com.ecommerce;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;

public class RefundService {

    // Assume we have a getConnection() method that returns a JDBC connection.
    private Connection getConnection() throws SQLException {
        // Implementation to return a valid connection
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "Pass@123");
    }

    public void processRefund(int orderId) throws SQLException {
        Connection connection = null;
        PreparedStatement checkOrderStmt = null;
        PreparedStatement insertRefundStmt = null;
        PreparedStatement updateOrderStmt = null;
        ResultSet orderResultSet = null;

        try {
            // Get a database connection
            connection = getConnection();
            connection.setAutoCommit(false);  // Start transaction

            // Step 1: Check if the order exists and is not already refunded
            String checkOrderQuery = "SELECT * FROM orders WHERE order_id = ? AND is_refund = FALSE AND Order_status=?";
            checkOrderStmt = connection.prepareStatement(checkOrderQuery);
            checkOrderStmt.setInt(1, orderId);
            checkOrderStmt.setString(2, "Canceled");
            orderResultSet = checkOrderStmt.executeQuery();

            if (!orderResultSet.next()) {
                throw new SQLException("Order not found or already refunded.");
            }

            // Step 2: Validate the refund amount
            double orderAmount = orderResultSet.getDouble("total_amount");
             double refundAmount=orderAmount-orderAmount*0.1;
//            if (refundAmount <= 0 || refundAmount > orderAmount) {
//                throw new SQLException("Invalid refund amount.");
//            }

            // Step 3: Insert a refund record into the refunds table
            String insertRefundQuery = "INSERT INTO refunds (order_id, refund_amount) VALUES (?, ?)";
            insertRefundStmt = connection.prepareStatement(insertRefundQuery, Statement.RETURN_GENERATED_KEYS);
            insertRefundStmt.setInt(1, orderId);
            insertRefundStmt.setDouble(2, refundAmount);
            int affectedRows = insertRefundStmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Failed to insert refund record.");
            }

            // Retrieve the generated refund_id
            int refundId = -1;
            ResultSet generatedKeys = insertRefundStmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                refundId = generatedKeys.getInt(1);
            }

            // Step 4: Update the order to mark it as refunded
            String updateOrderQuery = "UPDATE orders SET is_refund = TRUE WHERE order_id = ?";
            updateOrderStmt = connection.prepareStatement(updateOrderQuery);
            updateOrderStmt.setInt(1, orderId);
            int updatedRows = updateOrderStmt.executeUpdate();

            if (updatedRows == 0) {
                throw new SQLException("Failed to update order status to refunded.");
            }

            // Step 5: Commit the transaction
           
            connection.commit();
            System.out.println("Amount is refunded succesfully");
           
//            // Step 6: Create the Refund object and return it
//            Refund refund = new Refund(refundId, orderId, refundAmount);
//            return refund;

        } catch (SQLException e) {
            // Rollback the transaction in case of an error
            if (connection != null) {
                connection.rollback();
            }
            throw e;  // Rethrow the exception
        } finally {
            // Clean up resources
            if (orderResultSet != null) try { orderResultSet.close(); } catch (SQLException ignored) {}
            if (checkOrderStmt != null) try { checkOrderStmt.close(); } catch (SQLException ignored) {}
            if (insertRefundStmt != null) try { insertRefundStmt.close(); } catch (SQLException ignored) {}
            if (updateOrderStmt != null) try { updateOrderStmt.close(); } catch (SQLException ignored) {}
            if (connection != null) try { connection.setAutoCommit(true); connection.close(); } catch (SQLException ignored) {}
        }
    }
}

