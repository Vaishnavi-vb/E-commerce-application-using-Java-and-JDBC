package com.ecommerce;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class AddressService {

	// Database connection details
	static final String URL = "jdbc:mysql://localhost:3306/ecommerce";
	static final String USER = "root";
	static final String PASSWORD = "Pass@123";

	public static void addAddress(int userId) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter address_type:Home or Work");
		String addressType = scanner.next();
		if ("home".equalsIgnoreCase(addressType)) {

			// Ask for Home Address
			System.out.println("\nEnter Home Address:");
			System.out.print("Street Address: ");
			String homeStreetAddress = scanner.nextLine();
			scanner.nextLine();
			System.out.print("City: ");
			String homeCity = scanner.nextLine();
			System.out.print("State: ");
			String homeState = scanner.nextLine();
			System.out.print("Postal Code: ");
			String homePostalCode = scanner.nextLine();
			System.out.print("Country: ");
			String homeCountry = scanner.nextLine();
			System.out.print("Phone Number: ");
			String homePhoneNumber = scanner.nextLine();

			// Create Home Address object
			Address homeAddress = new Address(homeStreetAddress, homeCity, homeState, homePostalCode, homeCountry,
					homePhoneNumber, "Home");

			// Add Home Address to the database
			AddressService.saveAddress(userId, homeAddress);

		} else if ("work".equalsIgnoreCase(addressType)) {

			// Ask for Work Address
			System.out.println("\nEnter Work Address:");
			System.out.print("Street Address: ");
			String workStreetAddress = scanner.nextLine();
			scanner.nextLine();
			System.out.print("City: ");
			String workCity = scanner.nextLine();
			System.out.print("State: ");
			String workState = scanner.nextLine();
			System.out.print("Postal Code: ");
			String workPostalCode = scanner.nextLine();
			System.out.print("Country: ");
			String workCountry = scanner.nextLine();
			System.out.print("Phone Number: ");
			String workPhoneNumber = scanner.nextLine();

			// Create Work Address object
			Address workAddress = new Address(workStreetAddress, workCity, workState, workPostalCode, workCountry,
					workPhoneNumber, "Work");

			// Add Work Address to the database
			AddressService.saveAddress(userId, workAddress);
		}

		scanner.close();
	}

	// Add address to the database (Home or Work)
	public static void saveAddress(int userId, Address address) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			// Establish database connection
			connection = DriverManager.getConnection(URL, USER, PASSWORD);

			// SQL query to insert the address
			String sql = "INSERT INTO addresses (user_id, street_address, city, state, postal_code, country, phone_number, address_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, userId);
			preparedStatement.setString(2, address.getStreetAddress());
			preparedStatement.setString(3, address.getCity());
			preparedStatement.setString(4, address.getState());
			preparedStatement.setString(5, address.getPostalCode());
			preparedStatement.setString(6, address.getCountry());
			preparedStatement.setString(7, address.getPhoneNumber());
			preparedStatement.setString(8, address.getAddressType()); // "Home" or "Work"

			// Execute the query
			int rowsAffected = preparedStatement.executeUpdate();
			if (rowsAffected > 0) {
				System.out.println("Address added successfully!");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// Close resources
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	 public void updateAddress(int userId) {
	        Scanner scanner = new Scanner(System.in);

	        // Ask for the address type (Home or Work)
	        System.out.println("Enter address_type: Home or Work");
	        String addressType = scanner.nextLine();  // Use nextLine() to read the whole line

	        if ("home".equalsIgnoreCase(addressType)) {

	            // Ask for Home Address details
	            System.out.println("\nEnter Home Address:");
	            System.out.print("Street Address: ");
	            String homeStreetAddress = scanner.nextLine();

	            System.out.print("City: ");
	            String homeCity = scanner.nextLine();

	            System.out.print("State: ");
	            String homeState = scanner.nextLine();

	            System.out.print("Postal Code: ");
	            String homePostalCode = scanner.nextLine();

	            System.out.print("Country: ");
	            String homeCountry = scanner.nextLine();

	            System.out.print("Phone Number: ");
	            String homePhoneNumber = scanner.nextLine();

	            // Create Home Address object
	            Address address = new Address(homeStreetAddress, homeCity, homeState, homePostalCode, homeCountry,
	                    homePhoneNumber, "Home");

	            // Call the method to update address in the database
	            updateAddressInDatabase(address, userId);

	        } else if ("work".equalsIgnoreCase(addressType)) {

	            // Ask for Work Address details
	            System.out.println("\nEnter Work Address:");
	            System.out.print("Street Address: ");
	            String workStreetAddress = scanner.nextLine();

	            System.out.print("City: ");
	            String workCity = scanner.nextLine();

	            System.out.print("State: ");
	            String workState = scanner.nextLine();

	            System.out.print("Postal Code: ");
	            String workPostalCode = scanner.nextLine();

	            System.out.print("Country: ");
	            String workCountry = scanner.nextLine();

	            System.out.print("Phone Number: ");
	            String workPhoneNumber = scanner.nextLine();

	            // Create Work Address object
	            Address address = new Address(workStreetAddress, workCity, workState, workPostalCode, workCountry,
	                    workPhoneNumber, "Work");

	            // Call the method to update address in the database
	            updateAddressInDatabase(address, userId);

	        } else {
	            System.out.println("Invalid address type! Please enter either 'Home' or 'Work'.");
	        }

	        scanner.close();
	    }

	    // Method to update address in the database
	    private void updateAddressInDatabase(Address address, int userId) {
	        Connection connection = null;
	        PreparedStatement preparedStatement = null;

	        try {
	            // Establish database connection
	            connection = DriverManager.getConnection(URL, USER, PASSWORD);

	            // SQL query to update the address
	            String sql = "UPDATE addresses SET street_address = ?, city = ?, state = ?, postal_code = ?, country = ?, phone_number = ? "
	                    + "WHERE user_id = ? AND address_type = ?";

	            preparedStatement = connection.prepareStatement(sql);

	            // Set the parameters for the prepared statement
	            preparedStatement.setString(1, address.getStreetAddress());
	            preparedStatement.setString(2, address.getCity());
	            preparedStatement.setString(3, address.getState());
	            preparedStatement.setString(4, address.getPostalCode());
	            preparedStatement.setString(5, address.getCountry());
	            preparedStatement.setString(6, address.getPhoneNumber());
	            preparedStatement.setInt(7, userId);
	            preparedStatement.setString(8, address.getAddressType());  // Home or Work

	            // Execute the update
	            int rowsAffected = preparedStatement.executeUpdate();

	            if (rowsAffected > 0) {
	                System.out.println("Address updated successfully!");
	            } else {
	                System.out.println("No address found to update.");
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close resources
	            try {
	                if (preparedStatement != null)
	                    preparedStatement.close();
	                if (connection != null)
	                    connection.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
}
