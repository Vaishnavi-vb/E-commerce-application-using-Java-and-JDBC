package com.ecommerce;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CategoriesData {
	private static final String URL = "jdbc:mysql://localhost:3306/Ecommerce"; // Replace with your database URL
	private static final String USER = "root"; // Replace with your MySQL username
	private static final String PASSWORD = "Pass@123"; // Replace with your MySQL password

	public void addCategory(String categoryName) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatementCategory = null;
		Integer categoryId = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
			connection.setAutoCommit(false); // Begin transaction

			// Check if the category already exists
			String sqlCheckCategory = "SELECT category_id FROM categories WHERE name = ?";
			preparedStatementCategory = connection.prepareStatement(sqlCheckCategory);
			preparedStatementCategory.setString(1, categoryName);

			ResultSet rsCategory = preparedStatementCategory.executeQuery();
			if (rsCategory.next()) {
				categoryId = rsCategory.getInt("category_id");
				System.out.println("Category already exists with ID: " + categoryId);
			} else {
				String sqlInsertCategory = "INSERT INTO categories (name) VALUES (?)";
				preparedStatement = connection.prepareStatement(sqlInsertCategory);
				preparedStatement.setString(1, categoryName);
				preparedStatement.executeUpdate();

				// Commit the transaction after inserting
				connection.commit();

				System.out.println("Category '" + categoryName + "' added successfully!");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			try {
				if (connection != null) {
					connection.rollback(); // Rollback the transaction on error
					System.out.println("Transaction rolled back due to error.");
				}
			} catch (SQLException rollbackEx) {
				rollbackEx.printStackTrace();
			}
		} finally {
			// Close the resources properly
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (preparedStatementCategory != null)
					preparedStatementCategory.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void addSubCategories(String subcategories) {
		Scanner sc = new Scanner(System.in);
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatementSubCategory = null;
		Connection connection = null;
		Integer subCategoryId = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);

			// Check if the subcategory already exists
			String sqlCheckSubCategory = "SELECT sub_category_id FROM sub_categories WHERE name = ?";
			preparedStatementSubCategory = connection.prepareStatement(sqlCheckSubCategory);
			preparedStatementSubCategory.setString(1, subcategories);

			ResultSet rsSubCategory = preparedStatementSubCategory.executeQuery();
			if (rsSubCategory.next()) {
				subCategoryId = rsSubCategory.getInt("sub_category_id");
				System.out.println("Subcategory already exists with ID: " + subCategoryId);
			} else {

				System.out.println("Sub category does not exit please provide category name");
				String categoryName = sc.next();
				String sqlCheckCategory = "SELECT category_id FROM categories WHERE name = ?";
				preparedStatement = connection.prepareStatement(sqlCheckCategory);
				preparedStatement.setString(1, categoryName);
				ResultSet rsCategory = preparedStatement.executeQuery();
				if (rsCategory.next()) {
					int categoryId = rsCategory.getInt("category_id");
					System.out.println("Category already exists with ID: " + categoryId);

					String sqlInsertCategory = "INSERT INTO sub_categories (name, category_id) VALUES (?, ?)";
					;
					preparedStatement = connection.prepareStatement(sqlInsertCategory);
					preparedStatement.setString(1, subcategories);
					preparedStatement.setInt(2, categoryId);

					preparedStatement.executeUpdate();
					System.out.println("Sub_Category '" + subcategories + "' added successfully!");
				} else {
					System.out.println("category not exits enter frist category ");
				}

			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void showAllHomeApllience() {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatementProduct = null;
		int id = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);

			String category = "Home Appliences";
			String sqlCheck = "SELECT category_id FROM categories WHERE name = ?";
			preparedStatementProduct = connection.prepareStatement(sqlCheck);
			preparedStatementProduct.setString(1, category);
			ResultSet rs = preparedStatementProduct.executeQuery();

			if (rs.next()) {
				// Category exists, retrieve the ID
				id = rs.getInt("category_id");

			} else {
				System.out.println("Invalid category");
			}

			// Save Address
			String pSql = "select * from products where category_id=?";
			preparedStatement = connection.prepareStatement(pSql);
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (rs.next()) {
				// Print table header
				if (rs.getRow() == 1) {
					System.out.printf("+----------------+----------+----------------+-------------------+\n");
					System.out.printf("| Name           | Price    | Stock Quantity  | Description       |\n");
					System.out.printf("+----------------+----------+----------------+-------------------+\n");
				}

				// Retrieve data from result set
				String name = rs.getString("name");
				String price = rs.getString("price");
				String stockQuantity = rs.getString("stock_quantity");
				String description = rs.getString("description");

				// Print each row
				System.out.printf("| %-14s | %-8s | %-14s | %-17s |\n", name, price, stockQuantity, description);
				System.out.printf("+----------------+----------+----------------+-------------------+\n");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void showAllElectronics() {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatementProduct = null;
		int id = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);

			String category = "Electronics";
			String sqlCheck = "SELECT category_id FROM categories WHERE name = ?";
			preparedStatementProduct = connection.prepareStatement(sqlCheck);
			preparedStatementProduct.setString(1, category);
			ResultSet rs = preparedStatementProduct.executeQuery();

			if (rs.next()) {
				// Category exists, retrieve the ID
				id = rs.getInt("category_id");
				System.out.println("Category already exists with ID: " + id);
			} else {
				System.out.println("Invalid category");
				return; // Exit if the category is invalid
			}

			// Query for products in the specified category
			String pSql = "SELECT * FROM products WHERE category_id = ?";
			preparedStatement = connection.prepareStatement(pSql);
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();

			// Print table header
			System.out.printf("+----------------+----------+----------------+-------------------+\n");
			System.out.printf("| Name           | Price    | Stock Quantity | Description       |\n");
			System.out.printf("+----------------+----------+----------------+-------------------+\n");

			// Iterate over the result set for products
			while (resultSet.next()) {
				// Retrieve data from result set
				String name = resultSet.getString("name");
				String price = resultSet.getString("price");
				String stockQuantity = resultSet.getString("stock_quantity");
				String description = resultSet.getString("description");

				// Print each row
				System.out.printf("| %-14s | %-8s | %-14s | %-17s |\n", name, price, stockQuantity, description);
				System.out.printf("+----------------+----------+----------------+-------------------+\n");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (preparedStatementProduct != null)
					preparedStatementProduct.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void showMen() {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatementProduct = null;
		int id = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);

			String category = "Mens";
			String sqlCheck = "SELECT category_id FROM categories WHERE name = ?";
			preparedStatement = connection.prepareStatement(sqlCheck);
			preparedStatement.setString(1, category);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				// Category exists, retrieve the ID
				id = resultSet.getInt("category_id");
				System.out.println("Category already exists with ID: " + id);
				String pSql = "select * from products where category_id=?";
				preparedStatementProduct = connection.prepareStatement(pSql);
				preparedStatementProduct.setInt(1, id);
				ResultSet rs = preparedStatementProduct.executeQuery();

				while (rs.next()) {
					// Print table header
					if (rs.getRow() == 1) {
						System.out.printf("+----------------+----------+----------------+-------------------+\n");
						System.out.printf("| Name           | Price    | Stock Quantity  | Description       |\n");
						System.out.printf("+----------------+----------+----------------+-------------------+\n");
					}

					// Retrieve data from result set
					String name = rs.getString("name");
					String price = rs.getString("price");
					String stockQuantity = rs.getString("stock_quantity");
					String description = rs.getString("description");

					// Print each row
					System.out.printf("| %-14s | %-8s | %-14s | %-17s |\n", name, price, stockQuantity, description);
					System.out.printf("+----------------+----------+----------------+-------------------+\n");
				}

			} else {
				System.out.println("Invalid category");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void showWomens() {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatementProduct = null;
		int id = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);

			String category = "Womens";
			String sqlCheck = "SELECT category_id FROM categories WHERE name = ?";
			preparedStatement = connection.prepareStatement(sqlCheck);
			preparedStatement.setString(1, category);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				// Category exists, retrieve the ID
				id = resultSet.getInt("category_id");
				System.out.println("Category already exists with ID: " + id);
				String pSql = "select * from products where category_id=?";
				preparedStatementProduct = connection.prepareStatement(pSql);
				preparedStatementProduct.setInt(1, id);
				ResultSet rs = preparedStatementProduct.executeQuery();

				while (rs.next()) {
					// Print table header
					if (rs.getRow() == 1) {
						System.out.printf("+----------------+----------+----------------+-------------------+\n");
						System.out.printf("| Name           | Price    | Stock Quantity  | Description       |\n");
						System.out.printf("+----------------+----------+----------------+-------------------+\n");
					}

					// Retrieve data from result set
					String name = rs.getString("name");
					String price = rs.getString("price");
					String stockQuantity = rs.getString("stock_quantity");
					String description = rs.getString("description");

					// Print each row
					System.out.printf("| %-14s | %-8s | %-14s | %-17s |\n", name, price, stockQuantity, description);
					System.out.printf("+----------------+----------+----------------+-------------------+\n");
				}

			} else {
				System.out.println("Invalid category");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void showSport() {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatementProduct = null;
		int id = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);

			String category = "Sports";
			String sqlCheck = "SELECT category_id FROM categories WHERE name = ?";
			preparedStatement = connection.prepareStatement(sqlCheck);
			preparedStatement.setString(1, category);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				// Category exists, retrieve the ID
				id = resultSet.getInt("category_id");
				System.out.println("Category already exists with ID: " + id);
				String pSql = "select * from products where category_id=?";
				preparedStatementProduct = connection.prepareStatement(pSql);
				preparedStatementProduct.setInt(1, id);
				ResultSet rs = preparedStatementProduct.executeQuery();

				while (rs.next()) {
					// Print table header
					if (rs.getRow() == 1) {
						System.out.printf("+----------------+----------+----------------+-------------------+\n");
						System.out.printf("| Name           | Price    | Stock Quantity  | Description       |\n");
						System.out.printf("+----------------+----------+----------------+-------------------+\n");
					}

					// Retrieve data from result set
					String name = rs.getString("name");
					String price = rs.getString("price");
					String stockQuantity = rs.getString("stock_quantity");
					String description = rs.getString("description");

					// Print each row
					System.out.printf("| %-14s | %-8s | %-14s | %-17s |\n", name, price, stockQuantity, description);
					System.out.printf("+----------------+----------+----------------+-------------------+\n");
				}

			} else {
				System.out.println("Invalid category");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void showBook() {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatementProduct = null;
		int id = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);

			String category = "Books";
			String sqlCheck = "SELECT category_id FROM categories WHERE name = ?";
			preparedStatement = connection.prepareStatement(sqlCheck);
			preparedStatement.setString(1, category);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				// Category exists, retrieve the ID
				id = resultSet.getInt("category_id");
				System.out.println("Category already exists with ID: " + id);
				String pSql = "select * from products where category_id=?";
				preparedStatementProduct = connection.prepareStatement(pSql);
				preparedStatementProduct.setInt(1, id);
				ResultSet rs = preparedStatementProduct.executeQuery();

				while (rs.next()) {
					// Print table header
					if (rs.getRow() == 1) {
						System.out.printf("+----------------+----------+----------------+-------------------+\n");
						System.out.printf("| Name           | Price    | Stock Quantity  | Description       |\n");
						System.out.printf("+----------------+----------+----------------+-------------------+\n");
					}

					// Retrieve data from result set
					String name = rs.getString("name");
					String price = rs.getString("price");
					String stockQuantity = rs.getString("stock_quantity");
					String description = rs.getString("description");

					// Print each row
					System.out.printf("| %-14s | %-8s | %-14s | %-17s |\n", name, price, stockQuantity, description);
					System.out.printf("+----------------+----------+----------------+-------------------+\n");
				}

			} else {
				System.out.println("Invalid category");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	

}
