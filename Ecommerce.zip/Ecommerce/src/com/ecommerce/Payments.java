package com.ecommerce;

import java.time.LocalDateTime;

public class Payments {
	int paymentId;
	String paymentMethod;
	String paymentStatus;
	double amount;
	LocalDateTime paymentDate;

	public Payments() {
		// TODO Auto-generated constructor stub
	}

	public Payments(int paymentId, String paymentMethod, String paymentStatus, double amount,
			LocalDateTime paymentDate) {
		super();
		this.paymentId = paymentId;
		this.paymentMethod = paymentMethod;
		this.paymentStatus = paymentStatus;
		this.amount = amount;
		this.paymentDate = paymentDate;
	}

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public LocalDateTime getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(LocalDateTime paymentDate) {
		this.paymentDate = paymentDate;
	}

}
