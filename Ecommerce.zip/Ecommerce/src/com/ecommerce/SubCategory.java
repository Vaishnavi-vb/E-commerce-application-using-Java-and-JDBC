package com.ecommerce;

public class SubCategory {
     int subCategoryId;
     String subName;
     String subDescription;
     
     public SubCategory() {
		// TODO Auto-generated constructor stub
	}

	public SubCategory(String subName) {
		super();
		this.subName = subName;
		
	}

	public int getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(int subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getSubName() {
		return subName;
	}

	public void setSubName(String subName) {
		this.subName = subName;
	}

	public String getSubDescription() {
		return subDescription;
	}

	public void setSubDescription(String subDescription) {
		this.subDescription = subDescription;
	}
     
     
}
