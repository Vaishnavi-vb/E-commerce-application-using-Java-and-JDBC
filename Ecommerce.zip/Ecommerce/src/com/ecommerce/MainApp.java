package com.ecommerce;

import java.sql.SQLException;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		Authentication a = new Authentication();
		Scanner sc = new Scanner(System.in);
		int choice;

		do {
			System.out.println("Enter Choice\n1:Sign Up\n2:Login\n0:GO back");
			choice = sc.nextInt();
			switch (choice) {
			case 1: {
				String role;
				System.out.println("Enter your role (admin/user");
				role = sc.next();
				if (role.equalsIgnoreCase("Admin")) {
					a.registration(role);
				} else if (role.equalsIgnoreCase("User")) {
					a.registration(role);
				} else {
					System.out.println("Enter valid role");
				}

			}
				break;
			case 2: {
				a.login();
			}
				break;
			default: {
				System.out.println("Enter valid choice");
			}
				break;
			case 0: {
				System.out.println("Go back");
			}
			}
		} while (choice != 0);

		

	}
	

	
}
