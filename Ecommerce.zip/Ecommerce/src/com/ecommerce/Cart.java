package com.ecommerce;

import java.time.LocalDateTime;

public class Cart {
   int cartId;
   int quantity;
   LocalDateTime createdAt;
    LocalDateTime updatedAt;
    public Cart() {
		// TODO Auto-generated constructor stub
	}
	public Cart(int cartId, int quantity, LocalDateTime createdAt, LocalDateTime updatedAt) {
		super();
		this.cartId = cartId;
		this.quantity = quantity;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
    
}
