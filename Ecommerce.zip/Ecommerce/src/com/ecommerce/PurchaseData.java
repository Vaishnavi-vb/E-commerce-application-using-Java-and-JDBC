package com.ecommerce;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PurchaseData {

	private static final String URL = "jdbc:mysql://localhost:3306/Ecommerce"; // Replace with your database URL
	private static final String USER = "root"; // Replace with your MySQL username
	private static final String PASSWORD = "Pass@123"; // Replace with your MySQL password

	public void addToCart(int userId, int productId, int quantity) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			// Establish connection
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
			connection.setAutoCommit(false); // Start transaction

			// Check if user already has a cart
			String sqlGetCartId = "SELECT cart_id FROM cart WHERE user_id = ?";
			preparedStatement = connection.prepareStatement(sqlGetCartId);
			preparedStatement.setInt(1, userId);
			resultSet = preparedStatement.executeQuery();

			int cartId = -1;
			if (resultSet.next()) {
				cartId = resultSet.getInt("cart_id");
			} else {
				// If no cart exists, create a new one
				String sqlInsertCart = "INSERT INTO cart (user_id) VALUES (?)";
				preparedStatement = connection.prepareStatement(sqlInsertCart, Statement.RETURN_GENERATED_KEYS);
				preparedStatement.setInt(1, userId);
				preparedStatement.executeUpdate();

				// Retrieve the generated cart ID
				resultSet = preparedStatement.getGeneratedKeys();
				if (resultSet.next()) {
					cartId = resultSet.getInt(1);
				}
			}

			// Insert product into the cart
			if (cartId != -1) {
				String sqlInsertCartItem = "INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?, ?, ?)";
				preparedStatement = connection.prepareStatement(sqlInsertCartItem);
				preparedStatement.setInt(1, cartId);
				preparedStatement.setInt(2, productId);
				preparedStatement.setInt(3, quantity);
				preparedStatement.executeUpdate();
				System.out.println("Product added to cart.");
			}

			// Commit the transaction
			connection.commit();

		} catch (ClassNotFoundException | SQLException e) {
			// Rollback in case of an error
			if (connection != null) {
				connection.rollback();
				System.out.println("Transaction rolled back due to error.");
			}
			e.printStackTrace();
		} finally {
			// Close resources
			try {
				if (resultSet != null)
					resultSet.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public double reviewCart(int userId, Connection connection) throws SQLException {
		double totalAmount = 0;
		String sqlGetCartId = "SELECT cart_id FROM cart WHERE user_id = ?";
		PreparedStatement preparedStatement = connection.prepareStatement(sqlGetCartId);
		preparedStatement.setInt(1, userId);
		ResultSet resultSet = preparedStatement.executeQuery();

		if (resultSet.next()) {
			int cartId = resultSet.getInt("cart_id");

			String sqlGetCartItems = "SELECT p.name, ci.quantity, p.price FROM cart_items ci JOIN products p ON ci.product_id = p.product_id WHERE ci.cart_id = ?";
			preparedStatement = connection.prepareStatement(sqlGetCartItems);
			preparedStatement.setInt(1, cartId);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				double price = resultSet.getDouble("price");
				int quantity = resultSet.getInt("quantity");
				totalAmount += price * quantity;
			}
		}

		return totalAmount;
	}

	public int createOrder(int userId, double totalAmount, String paymentMethod, Connection connection)
			throws SQLException {
		String sqlInsertOrder = "INSERT INTO orders (user_id, total_amount, order_status, payment_status, payment_method) VALUES (?, ?, 'Pending', 'Pending', ?)";

		PreparedStatement preparedStatement = connection.prepareStatement(sqlInsertOrder,
				Statement.RETURN_GENERATED_KEYS);
		preparedStatement.setInt(1, userId);
		preparedStatement.setDouble(2, totalAmount);
		preparedStatement.setString(3, paymentMethod);
		preparedStatement.executeUpdate();

		ResultSet rs = preparedStatement.getGeneratedKeys();
		if (rs.next()) {
			return rs.getInt(1); // Return the generated order_id
		} else {
			throw new SQLException("Failed to create order, no ID obtained.");
		}
	}

	public void addOrderItems(int orderId, int[] productIds, int[] quantities, Connection connection)
			throws SQLException {
		String sqlInsertOrderItem = "INSERT INTO ordered_items (ordered_id, product_id, quantity, price, total_price) VALUES (?, ?, ?, ?, ?)";

		PreparedStatement preparedStatement = connection.prepareStatement(sqlInsertOrderItem);

		for (int i = 0; i < productIds.length; i++) {
			double price = getProductPrice(productIds[i], connection); // A helper method to get the price of a product
			double totalPrice = price * quantities[i];

			preparedStatement.setInt(1, orderId); // Set the order ID
			preparedStatement.setInt(2, productIds[i]); // Set product ID
			preparedStatement.setInt(3, quantities[i]); // Set quantity
			preparedStatement.setDouble(4, price); // Set price
			preparedStatement.setDouble(5, totalPrice); // Set total price for the item

			preparedStatement.addBatch(); // Add the insert statement to the batch
		}

		preparedStatement.executeBatch(); // Execute batch insert
		System.out.println("All items added to order.");
	}

	public double getProductPrice(int productId, Connection connection) throws SQLException {
	    System.out.println("Fetching price for productId: " + productId);  // Debugging the productId value
	    String sqlGetProductPrice = "SELECT price FROM products WHERE product_id = ?";
	    PreparedStatement preparedStatement = connection.prepareStatement(sqlGetProductPrice);
	    preparedStatement.setInt(1, productId);
	    ResultSet resultSet = preparedStatement.executeQuery();

	    if (resultSet.next()) {
	        double price = resultSet.getDouble("price");
	        System.out.println("Price for product " + productId + ": " + price);
	        return price;
	    } else {
	        System.out.println("No product found for productId: " + productId);
	        throw new SQLException("Product not found.");
	    }
	}


	public void processPayment(int orderId, String paymentMethod, double paymentAmount, Connection connection)
			throws SQLException {
		String sqlInsertPayment = "INSERT INTO payments (order_id, payment_method, payment_status, amount) VALUES (?, ?, 'Paid', ?)";

		PreparedStatement preparedStatement = connection.prepareStatement(sqlInsertPayment);
		preparedStatement.setInt(1, orderId);
		preparedStatement.setString(2, paymentMethod);
		preparedStatement.setDouble(3, paymentAmount);
		preparedStatement.executeUpdate();

		// Update order payment status
		String sqlUpdateOrder = "UPDATE orders SET payment_status = 'Paid' WHERE order_id = ?";
		preparedStatement = connection.prepareStatement(sqlUpdateOrder);
		preparedStatement.setInt(1, orderId);
		preparedStatement.executeUpdate();

		System.out.println("Payment processed successfully.");
	}

	public void updateOrderStatus(int orderId, String status, Connection connection) throws SQLException {
		String sqlUpdateOrderStatus = "UPDATE orders SET order_status = ? WHERE order_id = ?";

		PreparedStatement preparedStatement = connection.prepareStatement(sqlUpdateOrderStatus);
		preparedStatement.setString(1, status);
		preparedStatement.setInt(2, orderId);
		preparedStatement.executeUpdate();

		System.out.println("Order status updated to " + status);
	}

	public void cancelOrder(int orderId) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			// Establish connection
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
			connection.setAutoCommit(false); // Start transaction
		String sqlCancelOrder = "UPDATE orders SET order_status = 'Canceled' WHERE order_id = ?";

		 preparedStatement = connection.prepareStatement(sqlCancelOrder);
		preparedStatement.setInt(1, orderId);
		preparedStatement.executeUpdate();

		System.out.println("Order has been canceled.");
		// Commit the transaction
					connection.commit();

				} catch (ClassNotFoundException | SQLException e) {
					// Rollback in case of an error
					if (connection != null) {
						connection.rollback();
						System.out.println("Transaction rolled back due to error.");
					}
					e.printStackTrace();
				} finally {
					// Close resources
					try {
						if (resultSet != null)
							resultSet.close();
						if (preparedStatement != null)
							preparedStatement.close();
						if (connection != null)
							connection.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
	}

	public void completePurchase(int userId, String paymentMethod) throws SQLException {
		Connection connection = null;
		try {
			// Establish connection
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
			connection.setAutoCommit(false); // Start transaction

			// Step 1: Review the user's cart and get the total amount
			double totalAmount = reviewCart(userId, connection);
			if (totalAmount <= 0) {
				System.out.println("Cart is empty. Cannot proceed with the purchase.");
				return;
			}

			System.out.println("Total amount to pay: " + totalAmount);

			// Step 2: Create an order
			int orderId = createOrder(userId, totalAmount, paymentMethod, connection);
			System.out.println("Order created with ID: " + orderId);

			// Step 3: Get product IDs and quantities from the cart
			String sqlGetCartId = "SELECT cart_id FROM cart WHERE user_id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(sqlGetCartId);
			preparedStatement.setInt(1, userId);
			ResultSet resultSet = preparedStatement.executeQuery();

			int cartId = -1;
			if (resultSet.next()) {
				cartId = resultSet.getInt("cart_id");
			}

			String sqlGetCartItems = "SELECT product_id, quantity FROM cart_items WHERE cart_id = ?";
			preparedStatement = connection.prepareStatement(sqlGetCartItems);
			preparedStatement.setInt(1, cartId);
			resultSet = preparedStatement.executeQuery();

			// Prepare ArrayLists for productIds and quantities
			List<Integer> productIdsList = new ArrayList<>();
			List<Integer> quantitiesList = new ArrayList<>();

			while (resultSet.next()) {
			    productIdsList.add(resultSet.getInt("product_id"));
			    quantitiesList.add(resultSet.getInt("quantity"));
			}

			// Convert ArrayLists to arrays (if needed for addOrderItems method)
			int[] productIds = productIdsList.stream().mapToInt(Integer::intValue).toArray();
			int[] quantities = quantitiesList.stream().mapToInt(Integer::intValue).toArray();

			// Step 4: Add items to the order
			addOrderItems(orderId, productIds, quantities, connection);

			// Step 5: Process the payment
			processPayment(orderId, paymentMethod, totalAmount, connection);

			// Step 6: Update order status to 'Completed'
			updateOrderStatus(orderId, "Completed", connection);

			// Commit transaction
			connection.commit();
			System.out.println("Purchase completed successfully.");

		} catch (ClassNotFoundException | SQLException e) {
			// Rollback transaction if any error occurs
			if (connection != null) {
				connection.rollback();
				System.out.println("Transaction rolled back due to error.");
			}
			e.printStackTrace();
		} finally {
			// Close resources
			try {
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}


}
