package com.ecommerce;

import java.time.LocalDateTime;

public class Order {
	int orderId;
	int quantity;
	double price;
	String status;
	LocalDateTime date;
	
	public Order() {
		// TODO Auto-generated constructor stub
	}
	public Order(int orderId, int quantity, double price,String status, LocalDateTime date) {
		super();
		this.orderId = orderId;
		this.quantity = quantity;
		this.price = price;
		this.status = status;
		this.date = date;
		
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	

}
