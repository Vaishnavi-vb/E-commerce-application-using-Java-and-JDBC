package com.ecommerce;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Scanner;

public class Authentication {
	Scanner sc = new Scanner(System.in);

	private static final String URL = "jdbc:mysql://localhost:3306/Ecommerce"; // Replace with your database URL
	private static final String USER = "root"; // Replace with your MySQL username
	private static final String PASSWORD = "Pass@123"; // Replace with your MySQL password

	public void registration(String r) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter frist name");
		String firstName = sc.next();
		System.out.println("Enter last name");
		String lastName = sc.next();
		System.out.println("Enter emailId name");
		String emailId = sc.next();
		System.out.println("Enter mob no");
		long mobNo = sc.nextLong();
		System.out.println("Enter password");
		String password = sc.next();
		String role = r;
		LocalDateTime createdAt = LocalDateTime.now();
		LocalDateTime updatedAt = LocalDateTime.now();
		saveToDatabase(new User(firstName, lastName, emailId, mobNo, password, role));

	}

	public void login() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter emailId name");
		String emailId = sc.next();
//		System.out.println("Enter mob no");
//		long mobNo = sc.nextLong();
		System.out.println("Enter password");
		String password = sc.next();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			// Load the JDBC driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Establish a connection
			conn = DriverManager.getConnection(URL, USER, PASSWORD);

			// Check if the user ID exists
			String checkUserSql = "SELECT * FROM users WHERE email = ? and password=?";
			pstmt = conn.prepareStatement(checkUserSql);
			pstmt.setString(1, emailId);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				String role = rs.getString("role");
				System.out.println("Login Succesfullll--------");
				Menu menu=new Menu();
				if ("admin".equalsIgnoreCase(role)) {
					menu.availableServices();
				} else {
					menu.availableServicesForUser();
				}
			} else {
				System.out.println("Enter valid user_id and password");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {

			try {

				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public void saveToDatabase(User users) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);

			// Save Address
			String userSql = "INSERT INTO users (first_name, last_name, email, mob_no, password,role) VALUES (?, ?, ?, ?, ?,?)";
			preparedStatement = connection.prepareStatement(userSql, PreparedStatement.RETURN_GENERATED_KEYS);
			preparedStatement.setString(1, users.getFirstName());
			preparedStatement.setString(2, users.getLastName());
			preparedStatement.setString(3, users.getEmailId());
			preparedStatement.setLong(4, users.getMobNo());
			preparedStatement.setString(5, users.getPassword());
			preparedStatement.setString(6, users.getRole());
			preparedStatement.executeUpdate();

			System.out.println("user registraton succeful----------");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	

	


}
