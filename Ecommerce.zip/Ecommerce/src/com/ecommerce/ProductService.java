package com.ecommerce;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ProductService {

	Scanner sc = new Scanner(System.in);

	private static final String URL = "jdbc:mysql://localhost:3306/Ecommerce"; // Replace with your database URL
	private static final String USER = "root"; // Replace with your MySQL username
	private static final String PASSWORD = "Pass@123"; // Replace with your MySQL password

	public void addProduct(int userId) {
		String categoryName = null;
		String categorySubName = null;
		System.out.println("Entre product category");
		while (true) {
			categoryName = sc.nextLine();
			if (!isCategoryAvailable(categoryName)) {
				System.out.println("Enter valid category");
			} else {
				break;
			}
		}
		System.out.println("Entre product sub Category");
		while (true) {
			categorySubName = sc.nextLine();
			if (!isSubCategoryAvailable(categorySubName)) {
				System.out.println("Enter valid category");
			} else {
				break;
			}
		}
		System.out.println("Enter product name");
		String productName = sc.nextLine();
		System.out.println("Enter product price");
		double price = sc.nextDouble();
		System.out.println("Enter stock available");
		int stockQuantity = sc.nextInt();
		System.out.println("Give the short discription on product");
		String description = sc.nextLine();

		saveProduct(new Category(categoryName), new SubCategory(categorySubName), userId,
				new Product(productName, price, stockQuantity, description));
	}

	private boolean isCategoryAvailable(String categoryName) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
			connection.setAutoCommit(false); // Begin transaction

			// Check if the category already exists
			String sqlCheckCategory = "SELECT category_id FROM categories WHERE name = ?";
			preparedStatement = connection.prepareStatement(sqlCheckCategory);
			preparedStatement.setString(1, categoryName);

			ResultSet rsCategory = preparedStatement.executeQuery();
			if (rsCategory.next()) {
				return true;
			}

		} catch (ClassNotFoundException | SQLException e) {
			try {
				if (connection != null) {
					connection.rollback(); // Rollback transaction on error
				}
			} catch (SQLException rollbackEx) {
				rollbackEx.printStackTrace();
			}
			e.printStackTrace();

		}
		return false;
	}

	private boolean isSubCategoryAvailable(String subCategoryName) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
			connection.setAutoCommit(false); // Begin transaction

			// Check if the category already exists
			String sqlCheckCategory = "SELECT sub_category_id FROM sub_categories WHERE name = ?";
			preparedStatement = connection.prepareStatement(sqlCheckCategory);
			preparedStatement.setString(1, subCategoryName);

			ResultSet rsCategory = preparedStatement.executeQuery();
			if (rsCategory.next()) {
				return true;
			}

		} catch (ClassNotFoundException | SQLException e) {

			try {
				if (connection != null) {
					connection.rollback();
				}
			} catch (SQLException rollbackEx) {
				rollbackEx.printStackTrace();
			}
			e.printStackTrace();

		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public void saveProduct(Category category, SubCategory subCategory, int userId, Product product) {
			Connection connection = null;
			PreparedStatement preparedStatementCategory = null;
			PreparedStatement preparedStatementSubCategory = null;
			PreparedStatement preparedStatementInsertCategory = null;
			PreparedStatement preparedStatementInsertSubCategory = null;
			PreparedStatement preparedStatementInsertProduct = null;
			Integer categoryId = null;
			Integer subCategoryId = null;

			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				connection = DriverManager.getConnection(URL, USER, PASSWORD);
				connection.setAutoCommit(false); // Begin transaction

				// Check if the category already exists
				String sqlCheckCategory = "SELECT category_id FROM categories WHERE name = ?";
				preparedStatementCategory = connection.prepareStatement(sqlCheckCategory);
				preparedStatementCategory.setString(1, category.getCategoryName());

				ResultSet rsCategory = preparedStatementCategory.executeQuery();
				if (rsCategory.next()) {
					categoryId = rsCategory.getInt("category_id");
					System.out.println("Category already exists with ID: " + categoryId);
				} else {
					// Insert new category
					String sqlInsertCategory = "INSERT INTO categories (name) VALUES (?)";
					preparedStatementInsertCategory = connection.prepareStatement(sqlInsertCategory,
							PreparedStatement.RETURN_GENERATED_KEYS);
					preparedStatementInsertCategory.setString(1, category.getCategoryName());
					preparedStatementInsertCategory.executeUpdate();

					ResultSet generatedKeysCategory = preparedStatementInsertCategory.getGeneratedKeys();
					if (generatedKeysCategory.next()) {
						categoryId = generatedKeysCategory.getInt(1); // Retrieve the generated ID
					}
					System.out.println("New category added: " + category.getCategoryName());
				}

				// Check if the subcategory already exists
				String sqlCheckSubCategory = "SELECT sub_category_id FROM sub_categories WHERE name = ? AND category_id = ?";
				preparedStatementSubCategory = connection.prepareStatement(sqlCheckSubCategory);
				preparedStatementSubCategory.setString(1, subCategory.getSubName());
				preparedStatementSubCategory.setInt(2, categoryId);

				ResultSet rsSubCategory = preparedStatementSubCategory.executeQuery();
				if (rsSubCategory.next()) {
					subCategoryId = rsSubCategory.getInt("subcategory_id");
					System.out.println("Subcategory already exists with ID: " + subCategoryId);
				} else {
					// Insert new subcategory
					String sqlInsertSubCategory = "INSERT INTO sub_categories (name, category_id) VALUES (?, ?)";
					preparedStatementInsertSubCategory = connection.prepareStatement(sqlInsertSubCategory,
							PreparedStatement.RETURN_GENERATED_KEYS);
					preparedStatementInsertSubCategory.setString(1, subCategory.getSubName());
					preparedStatementInsertSubCategory.setInt(2, categoryId);
					preparedStatementInsertSubCategory.executeUpdate();

					ResultSet generatedKeysSubCategory = preparedStatementInsertSubCategory.getGeneratedKeys();
					if (generatedKeysSubCategory.next()) {
						subCategoryId = generatedKeysSubCategory.getInt(1); // Retrieve the generated ID
					}
					System.out.println("New subcategory added: " + subCategory.getSubName());
				}

				// Insert product
				String userSql = "INSERT INTO products (user_id, name, price, stock_quantity, description, sub_category_id) VALUES (?, ?, ?, ?, ?, ?)";
				preparedStatementInsertProduct = connection.prepareStatement(userSql,
						PreparedStatement.RETURN_GENERATED_KEYS);
				preparedStatementInsertProduct.setInt(1, userId);
				preparedStatementInsertProduct.setString(2, product.getProductName());
				preparedStatementInsertProduct.setDouble(3, product.getPrice());
				preparedStatementInsertProduct.setInt(4, product.getStockQuantity());
				preparedStatementInsertProduct.setString(5, product.getDescription());
				preparedStatementInsertProduct.setInt(6, subCategoryId);

				preparedStatementInsertProduct.executeUpdate();

				connection.commit(); // Commit transaction
				System.out.println("Product added successfully!");

			} catch (ClassNotFoundException | SQLException e) {
				try {
					if (connection != null) {
						connection.rollback(); // Rollback transaction on error
					}
				} catch (SQLException rollbackEx) {
					rollbackEx.printStackTrace();
				}
				e.printStackTrace();

			} finally {
				try {
					if (preparedStatementCategory != null)
						preparedStatementCategory.close();
					if (preparedStatementInsertCategory != null)
						preparedStatementInsertCategory.close();
					if (preparedStatementSubCategory != null)
						preparedStatementSubCategory.close();
					if (preparedStatementInsertSubCategory != null)
						preparedStatementInsertSubCategory.close();
					if (preparedStatementInsertProduct != null)
						preparedStatementInsertProduct.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			}

	public void showAllProduct() {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(URL, USER, PASSWORD);

			// Save Address
			String pSql = "select * from products";
			preparedStatement = connection.prepareStatement(pSql);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				System.out.println(rs.getString("name"));
				System.out.println(rs.getString("price"));
				System.out.println(rs.getString("stock_quantity"));
				System.out.println(rs.getString("description"));
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}
